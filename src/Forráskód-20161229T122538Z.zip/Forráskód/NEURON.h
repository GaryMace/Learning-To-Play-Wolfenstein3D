//
// Created by gary on 16/11/16.
//

class Neuron {
public:
    void foo();
    int bar(int x, int y);
};
